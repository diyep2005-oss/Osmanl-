package com.osmanli.tarayici;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;
import android.net.Uri;
import android.webkit.ValueCallback;
import android.webkit.DownloadListener;
import android.app.DownloadManager;
import android.os.Environment;

public class MainActivity extends Activity {
    private WebView web;
    private EditText address;
    private LinearLayout root;
    private static final int NAVY = Color.rgb(5, 18, 36);
    private static final int GOLD = Color.rgb(244, 193, 93);

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(NAVY);
        getWindow().setNavigationBarColor(NAVY);
        buildUi();
        web.loadUrl("file:///android_asset/index.html");
    }

    private void buildUi() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(NAVY);
        LinearLayout bar = new LinearLayout(this); bar.setPadding(10, 10, 10, 8); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setBackgroundColor(NAVY);
        address = new EditText(this); address.setSingleLine(true); address.setTextColor(Color.WHITE); address.setHintTextColor(0xFFB8C5D8); address.setHint("Ara veya URL yaz"); address.setTextSize(15); address.setPadding(15, 3, 8, 3); address.setBackground(roundBg(0xFF102642, GOLD, 32));
        address.setImeOptions(EditorInfo.IME_ACTION_GO);
        address.setOnEditorActionListener((v, actionId, event) -> { if (actionId == EditorInfo.IME_ACTION_GO) { navigate(address.getText().toString()); return true; } return false; });
        Button go = button("Git"); go.setOnClickListener(v -> navigate(address.getText().toString()));
        bar.addView(address, new LinearLayout.LayoutParams(0, 48, 1)); bar.addView(go, new LinearLayout.LayoutParams(64, 48)); root.addView(bar);

        web = new WebView(this); web.setBackgroundColor(NAVY); web.getSettings().setJavaScriptEnabled(true); web.getSettings().setDomStorageEnabled(true); web.getSettings().setLoadsImagesAutomatically(true); web.getSettings().setSupportZoom(true); web.getSettings().setBuiltInZoomControls(true); web.getSettings().setDisplayZoomControls(false);
        web.setWebViewClient(new WebViewClient() { @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) { if (url != null && !url.startsWith("file://")) address.setText(url); } });
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Object() {
            @android.webkit.JavascriptInterface public void open(String url) { runOnUiThread(() -> navigate(url)); }
            @android.webkit.JavascriptInterface public void home() { runOnUiThread(() -> web.loadUrl("file:///android_asset/index.html")); }
            @android.webkit.JavascriptInterface public void bookmark() { runOnUiThread(() -> { getPreferences(0).edit().putString("bookmark", web.getUrl()).apply(); Toast.makeText(MainActivity.this,"Favori kaydedildi",Toast.LENGTH_SHORT).show(); }); }
            @android.webkit.JavascriptInterface public String getBookmark() { return getPreferences(0).getString("bookmark", "https://www.google.com"); }
        }, "Browser");
        web.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try { DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url)); request.setTitle(android.webkit.URLUtil.guessFileName(url, contentDisposition, mimeType)); request.setDescription("Osmanlı Tarayıcı indiriyor"); request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED); request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, android.webkit.URLUtil.guessFileName(url, contentDisposition, mimeType)); ((DownloadManager)getSystemService(DOWNLOAD_SERVICE)).enqueue(request); Toast.makeText(this,"İndirme başlatıldı",Toast.LENGTH_SHORT).show(); }
            catch (Exception e) { Toast.makeText(this,"İndirme başlatılamadı",Toast.LENGTH_SHORT).show(); }
        });
        root.addView(web, new LinearLayout.LayoutParams(-1, 0, 1));
        LinearLayout bottom = new LinearLayout(this); bottom.setGravity(Gravity.CENTER); bottom.setPadding(4, 6, 4, 6); bottom.setBackgroundColor(0xFF08182D);
        addBottom(bottom,"⌂\nAna Sayfa", v -> web.loadUrl("file:///android_asset/index.html"));
        addBottom(bottom,"☆\nFavori", v -> { String u=getPreferences(0).getString("bookmark", "https://www.google.com"); navigate(u); });
        addBottom(bottom,"↶\nGeri", v -> { if(web.canGoBack()) web.goBack(); });
        addBottom(bottom,"↻\nYenile", v -> web.reload());
        addBottom(bottom,"⋮\nMenü", v -> Toast.makeText(this,"Menü: Favori kaydetmek için ana sayfadaki ☆ simgesini kullan.",Toast.LENGTH_LONG).show());
        root.addView(bottom); setContentView(root);
    }

    private void navigate(String text) {
        if (text == null || text.trim().isEmpty()) return;
        String q=text.trim();
        if (!q.contains(" ") && (q.matches("(?i)^[a-z][a-z0-9+.-]*://.*") || q.matches("(?i)^[a-z0-9.-]+\\.[a-z]{2,}(/.*)?$"))) {
            if (!q.matches("(?i)^[a-z][a-z0-9+.-]*://.*")) q="https://"+q;
        } else q="https://www.google.com/search?q="+Uri.encode(q);
        web.loadUrl(q);
    }
    private Button button(String text) { Button b=new Button(this); b.setText(text); b.setTextColor(GOLD); b.setAllCaps(false); b.setBackgroundColor(NAVY); return b; }
    private void addBottom(LinearLayout row, String label, View.OnClickListener listener) { TextView t=new TextView(this); t.setText(label); t.setTextColor(GOLD); t.setTextSize(12); t.setGravity(Gravity.CENTER); t.setPadding(3,6,3,6); row.addView(t,new LinearLayout.LayoutParams(0,52,1)); t.setOnClickListener(listener); }
    private android.graphics.drawable.GradientDrawable roundBg(int fill, int stroke, int radius) { android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable(); d.setColor(fill); d.setCornerRadius(radius); d.setStroke(1,stroke); return d; }
    @Override public void onBackPressed() { if(web != null && web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
