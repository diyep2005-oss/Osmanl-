# Osmanlı Tarayıcı — Android kaynak kodu

Bu proje, gönderdiğin ZIP'in içinden kaynak kod çıkmadığı için yeni hazırlanmış bir Android Studio başlangıç projesidir. ZIP'te yalnızca `app-debug.apk` bulunuyordu. Bu kaynak proje Osmanlı Tarayıcı adını, lacivert-altın görünümü ve özel tema görselini içerir.

## Derleme
1. Bilgisayara Android Studio kur.
2. Android Studio > Open ile `Osmanli-Tarayici` klasörünü aç.
3. Gradle eşitlemesi bitince Build > Build APK(s) seç.
4. APK genellikle `app/build/outputs/apk/debug/app-debug.apk` konumuna çıkar.

## Mevcut özellikler
- Google arama / URL açma
- Ana sayfada özel tema ve hızlı erişim bağlantıları
- Geri, yenile, ana sayfa
- Basit favori kaydetme ve açma
- İndirme bağlantılarında Android Download Manager kullanımı

## Henüz tamamlanmamış özellikler
Bu ilk kaynak sürümünde çoklu sekme yönetimi, gerçek gizli sekme, geçmiş ekranı, reklam engelleme motoru ve indirme ilerleme yüzdesi arayüzü henüz tam uygulanmış değildir. Reklam engelleme anahtarı görseli veya güvenlik kartı tek başına gerçek reklam engelleme/güvenlik koruması anlamına gelmez.
